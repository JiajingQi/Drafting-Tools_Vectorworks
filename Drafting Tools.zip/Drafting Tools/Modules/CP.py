#**********************************************
# March,4th, 2022. Ok. Created by Jiajing Qi
# Color Palette Tool
#   
#
#   Follow up www.7-lights.com for updates
#***********************************************
import vs
#import sys
#import math
#import shutil
import os
import ntpath
#from xml.dom import minidom
#import platform
import Fuctions

desktop = os.path.expanduser("~/Desktop")


def CP_tool():
    # control IDs
    kOK                   = 1
    kCancel               = 2
    kCP_GRoup             = 5
    kPalette_Name_Box     = 6
    kColor_Palette_Name   = 7
    kCP_Notice            = 8
    kCG1                  = 15
    kCG2                  = 16
    kCG3                  = 17
    kCG4                  = 18
    kCG5                  = 19
    kCG6                  = 20
    kCG7                  = 21
    kCG8                  = 22
    kCG9                  = 23
    kCG10                 = 24
    kL1                   = 25
    kL2                   = 26
    kL3                   = 27
    kL4                   = 28
    kL5                   = 29
    kL6                   = 30
    kL7                   = 31
    kL8                   = 32
    kL9                   = 33
    kL10                  = 34
    kC1                   = 35
    kC2                   = 36
    kC3                   = 37
    kC4                   = 38
    kC5                   = 39
    kC11                  = 40
    kC21                  = 41
    kC31                  = 42
    kC41                  = 43
    kC51                  = 44
    kReset_Name           = 45
    kCreate_CP            = 56
    kReset_Color          = 57
    kIO                   = 327
    kIn                   = 328
    kOut                  = 329
    kUnnamed322           = 330
    kUnnamed3221          = 331
    kUnnamed32211         = 332
    kSetUpDialogC         = 12255   # predefined dialog event constant used for setup BEFORE dialog runs
    kSetDownDialogC       = 12256   # predefined dialog event constant used for setup AFTER dialog runs

    def CreateDialog():
        # Alignment constants
        kRight                = 1
        kBottom               = 2
        kLeft                 = 3
        kColumn               = 4
        kResize               = 0
        kShift                = 1

        def GetPluginString(ndx):
            # Static Text
            if ndx == 1001:         return ''
            elif ndx == 1002:       return ''
            elif ndx == 1003:       return 'Color Palette Tool'
            elif ndx == 1005:       return 'Create Color Palette'
            elif ndx == 1006:       return 'Enter Color Palette Name'
            elif ndx == 1007:       return ''
            elif ndx == 1008:       return 'NOTE: Color labled ''N/A'' will not be included into color palette.'
            elif ndx == 1015:       return 'Color #1'
            elif ndx == 1016:       return 'Color #2'
            elif ndx == 1017:       return 'Color #3'
            elif ndx == 1018:       return 'Color #4'
            elif ndx == 1019:       return 'Color #5'
            elif ndx == 1020:       return 'Color #6'
            elif ndx == 1021:       return 'Color #7'
            elif ndx == 1022:       return 'Color #8'
            elif ndx == 1023:       return 'Color #9'
            elif ndx == 1024:       return 'Color #10'
            elif ndx == 1025:       return 'N/A'
            elif ndx == 1026:       return 'N/A'
            elif ndx == 1027:       return 'N/A'
            elif ndx == 1028:       return 'N/A'
            elif ndx == 1029:       return 'N/A'
            elif ndx == 1030:       return 'N/A'
            elif ndx == 1031:       return 'N/A'
            elif ndx == 1032:       return 'N/A'
            elif ndx == 1033:       return 'N/A'
            elif ndx == 1034:       return 'N/A'
            elif ndx == 1035:       return ''
            elif ndx == 1036:       return ''
            elif ndx == 1037:       return ''
            elif ndx == 1038:       return ''
            elif ndx == 1039:       return ''
            elif ndx == 1040:       return ''
            elif ndx == 1041:       return ''
            elif ndx == 1042:       return ''
            elif ndx == 1043:       return ''
            elif ndx == 1044:       return ''
            elif ndx == 1045:       return 'Reset Names'
            elif ndx == 1056:       return 'Create Color Palette'
            elif ndx == 1057:       return 'Reset Colors'
            elif ndx == 1327:       return 'Color Palette Import / Export'
            elif ndx == 1328:       return 'Import'
            elif ndx == 1329:       return 'Export'
            elif ndx == 1330:       return 'Created By 7-Lights'
            elif ndx == 1331:       return 'Updated: 2022-01-25'
            elif ndx == 1332:       return 'www.7-lights.com'
            # Help Text
            elif ndx == 2001:       return 'Accepts the dialog data.'
            elif ndx == 2002:       return 'Cancels the dialog data.'
            elif ndx == 2005:       return 'Help text.'
            elif ndx == 2006:       return 'Help text.'
            elif ndx == 2007:       return 'Enter Color Palette Name'
            elif ndx == 2008:       return 'Help text.'
            elif ndx == 2015:       return 'Set color and name'
            elif ndx == 2016:       return 'Set color and name'
            elif ndx == 2017:       return 'Set color and name'
            elif ndx == 2018:       return 'Set color and name'
            elif ndx == 2019:       return 'Set color and name'
            elif ndx == 2020:       return 'Set color and name'
            elif ndx == 2021:       return 'Set color and name'
            elif ndx == 2022:       return 'Set color and name'
            elif ndx == 2023:       return 'Set color and name'
            elif ndx == 2024:       return 'Set color and name'
            elif ndx == 2025:       return 'Help text.'
            elif ndx == 2026:       return 'Help text.'
            elif ndx == 2027:       return 'Help text.'
            elif ndx == 2028:       return 'Help text.'
            elif ndx == 2029:       return 'Help text.'
            elif ndx == 2030:       return 'Help text.'
            elif ndx == 2031:       return 'Help text.'
            elif ndx == 2032:       return 'Help text.'
            elif ndx == 2033:       return 'Help text.'
            elif ndx == 2034:       return 'Help text.'
            elif ndx == 2035:       return 'Help text.'
            elif ndx == 2036:       return 'Help text.'
            elif ndx == 2037:       return 'Help text.'
            elif ndx == 2038:       return 'Help text.'
            elif ndx == 2039:       return 'Help text.'
            elif ndx == 2040:       return 'Help text.'
            elif ndx == 2041:       return 'Help text.'
            elif ndx == 2042:       return 'Help text.'
            elif ndx == 2043:       return 'Help text.'
            elif ndx == 2044:       return 'Help text.'
            elif ndx == 2045:       return 'Reset all names back to ''N/A'''
            elif ndx == 2056:       return 'Create Color Palette'
            elif ndx == 2057:       return 'Reset color back to default.'
            elif ndx == 2327:       return ''
            elif ndx == 2328:       return 'Import a XML file as color palette'
            elif ndx == 2329:       return 'Export a exiting color palette as XML file.'
            elif ndx == 2330:       return 'Help text.'
            elif ndx == 2331:       return 'Help text.'
            elif ndx == 2332:       return 'Help text.'
            return ''

        def GetStr(ndx):
            result = GetPluginString( ndx + 1000 )
            return result

        def GetHelpStr(ndx):
            result = GetPluginString( ndx + 2000 )
            return result

        dialog = vs.CreateLayout( GetStr(3), True, GetStr(kOK), GetStr(kCancel) )

        # create controls
        vs.CreateGroupBox( dialog, kIO, GetStr(kIO), True )
        vs.CreatePushButton( dialog, kIn, GetStr(kIn) )
        vs.CreatePushButton( dialog, kOut, GetStr(kOut) )
        vs.CreateCheckBoxGroupBox( dialog, kCP_GRoup, GetStr(kCP_GRoup), True )
        vs.CreateGroupBox( dialog, kPalette_Name_Box, GetStr(kPalette_Name_Box), True )
        vs.CreateEditText( dialog, kColor_Palette_Name, GetStr(kColor_Palette_Name), 16 )
        vs.CreateGroupBox( dialog, kCG1, GetStr(kCG1), True )
        vs.CreateEditText( dialog, kL1, GetStr(kL1), 16 )
        vs.CreateColorPopup( dialog, kC1, 16 )
        vs.CreateGroupBox( dialog, kCG6, GetStr(kCG6), True )
        vs.CreateEditText( dialog, kL6, GetStr(kL6), 16 )
        vs.CreateColorPopup( dialog, kC11, 16 )
        vs.CreateGroupBox( dialog, kCG2, GetStr(kCG2), True )
        vs.CreateEditText( dialog, kL2, GetStr(kL2), 16 )
        vs.CreateColorPopup( dialog, kC2, 16 )
        vs.CreateGroupBox( dialog, kCG7, GetStr(kCG7), True )
        vs.CreateEditText( dialog, kL7, GetStr(kL7), 16 )
        vs.CreateColorPopup( dialog, kC21, 16 )
        vs.CreateGroupBox( dialog, kCG3, GetStr(kCG3), True )
        vs.CreateEditText( dialog, kL3, GetStr(kL3), 16 )
        vs.CreateColorPopup( dialog, kC3, 16 )
        vs.CreateGroupBox( dialog, kCG8, GetStr(kCG8), True )
        vs.CreateEditText( dialog, kL8, GetStr(kL8), 16 )
        vs.CreateColorPopup( dialog, kC31, 16 )
        vs.CreateGroupBox( dialog, kCG4, GetStr(kCG4), True )
        vs.CreateEditText( dialog, kL4, GetStr(kL4), 16 )
        vs.CreateColorPopup( dialog, kC4, 16 )
        vs.CreateGroupBox( dialog, kCG9, GetStr(kCG9), True )
        vs.CreateEditText( dialog, kL9, GetStr(kL9), 16 )
        vs.CreateColorPopup( dialog, kC41, 16 )
        vs.CreateGroupBox( dialog, kCG5, GetStr(kCG5), True )
        vs.CreateEditText( dialog, kL5, GetStr(kL5), 16 )
        vs.CreateColorPopup( dialog, kC5, 16 )
        vs.CreateGroupBox( dialog, kCG10, GetStr(kCG10), True )
        vs.CreateEditText( dialog, kL10, GetStr(kL10), 16 )
        vs.CreateColorPopup( dialog, kC51, 16 )
        vs.CreateStaticText( dialog, kCP_Notice, GetStr(kCP_Notice), -1 )
        vs.CreatePushButton( dialog, kReset_Name, GetStr(kReset_Name) )
        vs.CreatePushButton( dialog, kReset_Color, GetStr(kReset_Color) )
        vs.CreatePushButton( dialog, kCreate_CP, GetStr(kCreate_CP) )
        vs.CreateStaticText( dialog, kUnnamed322, GetStr(kUnnamed322), -1 )
        vs.CreateStaticText( dialog, kUnnamed3221, GetStr(kUnnamed3221), -1 )
        vs.CreateStaticText( dialog, kUnnamed32211, GetStr(kUnnamed32211), -1 )

        # set relations
        vs.SetFirstLayoutItem( dialog, kIO )
        vs.SetFirstGroupItem( dialog, kIO, kIn )
        vs.SetRightItem( dialog, kIO, kCP_GRoup, 0, 0 )
        vs.SetBelowItem( dialog, kIO, kUnnamed322, 0, 0 )
        vs.SetRightItem( dialog, kIn, kOut, 0, 0 )
        vs.SetFirstGroupItem( dialog, kCP_GRoup, kPalette_Name_Box )
        vs.SetFirstGroupItem( dialog, kPalette_Name_Box, kColor_Palette_Name )
        vs.SetBelowItem( dialog, kPalette_Name_Box, kCG1, 0, 0 )
        vs.SetFirstGroupItem( dialog, kCG1, kL1 )
        vs.SetRightItem( dialog, kCG1, kCG6, 0, 0 )
        vs.SetBelowItem( dialog, kCG1, kCG2, 0, 0 )
        vs.SetRightItem( dialog, kL1, kC1, 0, 0 )
        vs.SetFirstGroupItem( dialog, kCG6, kL6 )
        vs.SetRightItem( dialog, kL6, kC11, 0, 0 )
        vs.SetFirstGroupItem( dialog, kCG2, kL2 )
        vs.SetRightItem( dialog, kCG2, kCG7, 0, 0 )
        vs.SetBelowItem( dialog, kCG2, kCG3, 0, 0 )
        vs.SetRightItem( dialog, kL2, kC2, 0, 0 )
        vs.SetFirstGroupItem( dialog, kCG7, kL7 )
        vs.SetRightItem( dialog, kL7, kC21, 0, 0 )
        vs.SetFirstGroupItem( dialog, kCG3, kL3 )
        vs.SetRightItem( dialog, kCG3, kCG8, 0, 0 )
        vs.SetBelowItem( dialog, kCG3, kCG4, 0, 0 )
        vs.SetRightItem( dialog, kL3, kC3, 0, 0 )
        vs.SetFirstGroupItem( dialog, kCG8, kL8 )
        vs.SetRightItem( dialog, kL8, kC31, 0, 0 )
        vs.SetFirstGroupItem( dialog, kCG4, kL4 )
        vs.SetRightItem( dialog, kCG4, kCG9, 0, 0 )
        vs.SetBelowItem( dialog, kCG4, kCG5, 0, 0 )
        vs.SetRightItem( dialog, kL4, kC4, 0, 0 )
        vs.SetFirstGroupItem( dialog, kCG9, kL9 )
        vs.SetRightItem( dialog, kL9, kC41, 0, 0 )
        vs.SetFirstGroupItem( dialog, kCG5, kL5 )
        vs.SetRightItem( dialog, kCG5, kCG10, 0, 0 )
        vs.SetBelowItem( dialog, kCG5, kCP_Notice, 0, 0 )
        vs.SetRightItem( dialog, kL5, kC5, 0, 0 )
        vs.SetFirstGroupItem( dialog, kCG10, kL10 )
        vs.SetRightItem( dialog, kL10, kC51, 0, 0 )
        vs.SetBelowItem( dialog, kCP_Notice, kReset_Name, 0, 0 )
        vs.SetRightItem( dialog, kReset_Name, kReset_Color, 0, 0 )
        vs.SetRightItem( dialog, kReset_Color, kCreate_CP, 0, 0 )
        vs.SetBelowItem( dialog, kUnnamed322, kUnnamed3221, 0, 0 )
        vs.SetBelowItem( dialog, kUnnamed3221, kUnnamed32211, 0, 0 )

        # set alignments

        # set help strings
        cnt = 1
        while ( cnt <= 332 ):
            vs.SetHelpText( dialog, cnt, GetHelpStr(cnt) )
            cnt += 1

        return dialog


        
    def DialogHandler(item, data):
        Checkbox_Status = vs.GetBooleanItem(Color_Palette_Tool,5)
        Color_Palette_Name = vs.GetItemText(Color_Palette_Tool,7)
        Color_Palette_Name_EXT = vs.GetItemText(Color_Palette_Tool,7)+'.xml'
        #Import Color Palette
        if item == 12255:
            pass
        elif item == 328:
            # User select file to import
            YoN,Filepath = vs.GetFileN ('IMPORT XML file as a color palette',desktop,'xml')
            Filepath = Filepath.replace("\\","/")
            #Get selected file name with extension
            Filename_EXT = ntpath.basename(Filepath)
            # Get selected file name without extension
            Filename = os.path.splitext(Filename_EXT)[0]
            if YoN == True :
                dst_path = vs.GetFolderPath(137).replace("\\","/")
                if Fuctions.Check_Exists(dst_path,Filename_EXT) == True:
                    if vs.AlertQuestion (f'"{Filename}" exists already, would you like to overwrite?','','0','Overwrite','','','') ==1:
                        Fuctions.Imp_Palette(Filepath, dst_path,Filename)
                        item = 1
                    
                else:
                    Fuctions.Imp_Palette(Filepath, dst_path,Filename)
                    item = 1
            

                    
        #Export Color Palette       
        elif item == 329:
            # Navegate to Color Palette folder
            scr_path= vs.GetFolderPath(137)
            #User selects a color palette to back up
            YoN,Filepath = vs.GetFileN ('Choose a color palette to export',scr_path,'xml')
            #Change filepath \ to /.
            Filepath = Filepath.replace("\\","/")
            #Get selected file name with extension
            Filename_EXT = ntpath.basename(Filepath)
            # Get selected file name without extension
            Filename = os.path.splitext(Filename_EXT)[0]
            if YoN == True:
                vs.AlertInform ('Now choose a folder to back up the selected color palette','',False)
                ok,dst_path = vs.GetFolder('Choose a folder to save selected color palette')
                dst_path = dst_path.replace("\\","/")
                if ok == 0:
                    if Fuctions.Check_Exists(dst_path,Filename_EXT) == True:
                        if vs.AlertQuestion (f'"{Filename}" exists already, would you like to overwrite?','','0','Overwrite','','','') ==1:
                            Fuctions.Exp_Palette (Filepath, dst_path,Filename)
                            item = 1
                    else:
                        Fuctions.Exp_Palette (Filepath, dst_path,Filename)
                        item = 1
            
                    
    ## Create Color Palette 

        #Create Color Name and ColorIndex list
        elif item==56 and Checkbox_Status == True and Color_Palette_Name != '':
            Clr_Dic ={}
            Clr_Name = []
            Clr_Val  = []
            scr_path= vs.GetFolderPath(137) # Navegate to Color Palette folder
            x = 25
            for x in range(25,35):
                Name = vs.GetItemText(Color_Palette_Tool,vs.Str2Num(x))
                Color = vs.GetColorChoice(Color_Palette_Tool,vs.Str2Num(x+10))
                Clr_Dic[Name] = Color
            invalid_Chr = ["<",">",":",'"',"/","*",'?',"|","\\",':','.']
            Goodname = True
            for x in Color_Palette_Name.replace(' ',''):
                if x in invalid_Chr:
                    vs.AlertCritical('Invalid Color Palette Name, "{}" is a special character.'.format(x),'Change palette name and try again!')          
                    Goodname = False
            if Fuctions.checkKey(Clr_Dic,'N/A') ==True and Goodname == True:
                del Clr_Dic['N/A']

            if len(Clr_Dic) ==0 and Goodname == True:
                vs.AlertCritical('Name a color to start!','')
            if Fuctions.checkVal(Clr_Dic, -1) ==True and len(Clr_Dic) !=0 and Goodname == True:

                index = list(Clr_Dic.values()).index(-1)

                i = list(Clr_Dic.keys())[index]
                vs.AlrtDialog(f'Choose a color for color titled {i}, then try again!','')
            if Fuctions.checkVal(Clr_Dic, -1) ==False  and len(Clr_Dic) !=0 and Goodname == True: 
                Clr_Name = list(Clr_Dic.keys())
                Clr_Val = list(Clr_Dic.values()) #Get a list of color index
                
        
                Clr_QTY = len(Clr_Name)
                if Fuctions.Check_Exists(scr_path,Color_Palette_Name_EXT) == True:
                    if vs.AlertQuestion (f'"{Color_Palette_Name}" exists already, would you like to overwrite?','','0','Overwrite','','','') ==1:
                        Fuctions.XML_W (Color_Palette_Name,Clr_QTY,Clr_Val,Clr_Name,scr_path)
                else:
                    Fuctions.XML_W (Color_Palette_Name,Clr_QTY,Clr_Val,Clr_Name,scr_path)


        elif item==56 and  Checkbox_Status == True and Color_Palette_Name == '':
            vs.AlrtDialog('Enter a palette name to start!')

            #Reset Name
        elif item == 45 :
            i = 25
            for i in range (25,35):
                vs.SetItemText(Color_Palette_Tool,vs.Str2Num(i),'N/A')
                i+=1
        #Reset Color
        elif item == 57 :
            i = 35
            for i in range (35,45):
                vs.SetColorChoice(Color_Palette_Tool,vs.Str2Num(i),0)
                i+=1
        
        return item 

            

    Color_Palette_Tool= CreateDialog()
    vs.RunLayoutDialog( Color_Palette_Tool, DialogHandler )

