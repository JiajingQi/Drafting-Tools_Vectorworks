#**********************************************
# March,4th, 2022. Ok. Created by Jiajing Qi
# Bitmap Tools
#   
#  
#   Follow up www.7-lights.com for updates
#***********************************************
import vs
import math

def Bitmap():
	ALayerN = "'"+ vs.GetLName(vs.ActLayer())+"'"
		#Check any bitmaps are selected.
	def checkifImages():
		vs.SelectObj(Criteria)
		if int(vs.NumSelectedObjects()) == 0:
			i = vs.AlertInform("No Bitmaps Found"," Please import images and run script again",False)
			return False
		else:
			vs.DSelectAll()
			return True
		
	def ToDo(h):
		#Get OBJ Height
		GH = vs.HHeight(h)
		#Get OBJ Width
		GW = vs.HWidth(h)
		#Get ratio on Height
		RatH = UH / GH
		#Get ratio on Width
		RatW = UW / GW
		#Get OBJ center point
		xcen, ycen = vs.HCenter(h)
		#Scaling bitmap
		vs.HScale2D(h,xcen,ycen,RatW,RatH,False)

	#Main loop
	UserCancel = False
	#Create different Criteria(Current layer or all layer)
	i = vs.AlertQuestion('This script will resize bitmaps, choose from the following options.', 'Which bitmap you would like to resize?', 1, 'All Layers', 'Cancel', 'ONLY On Layer {}'.format(ALayerN), '')
	if i == 2:
		Criteria = "INSYMBOL & INVIEWPORT & ((L=LayerName) & (T=BITMAP))".replace("LayerName",ALayerN)
	elif i ==1:
		Criteria = "(T = BITMAP)"
	else:
		UserCancel = True
	
	if UserCancel == False:	
		if checkifImages() == True:
			UW = vs.DistDialog('Set WIDTH : \n Note: Default unit is imperial, specify unit marker for metric!',"")
				#Convert input to feet/inch
			UW_IN, UW_FT = math.modf(UW/12) 
			UW_FT_R = int(UW_FT)
			UW_IN_R = int(round(UW_IN,1)*10)
			#User set WIDTH and HEIGHT for bitmaps
			if UW !=0:
				UH = vs.DistDialog('Set HEIGHT : \n Note: Default unit is imperial, specify unit marker for metric! ',f"{UW_FT_R}'{UW_IN_R}")
				if not vs.DidCancel() and UH!=0:
					vs.ForEachObject(ToDo, Criteria)
					UH_IN , UH_FT = math.modf(UH/12)
					UH_FT_R = int(UW_FT)
					UH_IN_R = int(round(UW_IN,1)*10)
					vs.AlrtDialog(f"Done,Bitmaps have been resized to {UW_FT_R}' {UW_IN_R}",'"',f" X {UH_FT_R}' {UH_IN_R}",'"')
				elif UH ==0:
					vs.AlertCritical('Invalid Value', 'Run Script again and enter a valid number.')
				
			else:
				vs.AlertCritical('Invalid Value', 'Run Script again and enter a valid number.')