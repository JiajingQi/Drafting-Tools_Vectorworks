
    
import vs
import subprocess
import sys
import math
import shutil
import os
import ntpath
from xml.dom import minidom
import platform

desktop = os.path.expanduser("~/Desktop")

def RGBTOCMYK (ColorIndex):
    #get RGB color in 16bit
    r,g,b = vs.ColorIndexToRGB(ColorIndex)
    
    C = 1- (r/65535)
    M = 1 - (g/65535)
    Y = 1 - (b/65535)
    
    var_K = 1

    if ( C < var_K ):   
        var_K = C
    if ( M < var_K ):   
        var_K = M
    if ( Y < var_K ):   
        var_K = Y
    if ( var_K == 1 ): 
        C = 0          
        M = 0
        Y = 0
    else:
        C = ( C - var_K ) / ( 1 - var_K )
        M = ( M - var_K ) / ( 1 - var_K )
        Y = ( Y - var_K ) / ( 1 - var_K )

    K = var_K
    return C,M,Y,K

#check if file already exist    
def Check_Exists(dst_path,Filename_EXT):
    Check_file = dst_path + Filename_EXT
    return os.path.exists(Check_file)
    
def Imp_Palette(Filepath, dst_path,Filename):
    #Copy file
    shutil.copy(Filepath, dst_path)
    #Sucess info alert!
    Note = 'Color palette {} created!'.format(Filename)
    Note1 = 'Visit help page'
    Page_name = 'Managing Color Palettes'
    Hlink = 'https://app-help.vectorworks.net/2016/eng/VW2016_Guide/Attributes/Managing_Color_Palettes.htm'
    Note2 = 'for more information on how to active color palette {}.'.format(Filename)
    vs.AlertInformHLink(Note, Note1, Page_name, Hlink,Note2 , False);
    
def Exp_Palette (Filepath, dst_path,Filename):
    #Copy file
    shutil.copy (Filepath,dst_path)
    #Final
    question = f'Color palette "{Filename}" exported successfully, would you like to open the destination folder?'
    advice  = ''
    defaultButton = 1
    OKOverrideText = 'Open Destional Folder'
    CancelOverrideText  = 'Done'
    customButtonAText = ''
    customButtonBText = ''
    if vs.AlertQuestion (question, advice, defaultButton, OKOverrideText, CancelOverrideText, customButtonAText, customButtonBText) ==1:
        if platform.system() =='Windows':
            os.startfile(dst_path)
        else:
            subprocess.Popen(['open',dst_path])

def XML_W (U_Palette_NAME,Clr_QTY,Clr_Value,Clr_Name,dst_path):
    i = 0  
    root = minidom.Document()
  
    xml = root.createElement('ColorPalette') 
    root.appendChild(xml)
  
    Palette_Name= root.createElement('N')
    Palette_Name.appendChild(root.createTextNode(U_Palette_NAME))
    xml.appendChild(Palette_Name)

    Clr_List = root.createElement('ColorList')
    xml.appendChild(Clr_List)

    for i in range(0,Clr_QTY):
        # Individual color
        Clr_Head = root.createElement('C')
        Clr_List.appendChild(Clr_Head)

        C,M,Y,K = RGBTOCMYK (Clr_Value[i])
    
        
        Clr_Val = root.createElement('D')
        Clr_Val.appendChild(root.createTextNode(f'{C},{M},{Y},{K}'))
        Clr_Head.appendChild(Clr_Val)

        U_Clr_Name = Clr_Name[i]
    
        Ind_Clr_Name = root.createElement('N')
        Ind_Clr_Name.appendChild(root.createTextNode(f'{U_Clr_Name}'))
        Clr_Head.appendChild(Ind_Clr_Name)


  
    xml_str = root.toprettyxml(indent ="\t") 
    # Navegate to Color Palette folder
    

    save_path_file = os.path.expanduser(f"{dst_path}{U_Palette_NAME}.xml")
  
    with open(save_path_file, "w") as f:
        f.write(xml_str) 
    #Sucess info alert!
    Note = 'Color palette {} created!'.format(U_Palette_NAME)
    Note1 = 'Visit help page'
    Page_name = 'Managing Color Palettes'
    Hlink = 'https://app-help.vectorworks.net/2016/eng/VW2016_Guide/Attributes/Managing_Color_Palettes.htm'
    Note2 = 'for more information on how to active color palette {}.'.format(U_Palette_NAME)
    vs.AlertInformHLink(Note, Note1, Page_name, Hlink,Note2 , False);
    
        
def checkKey(dict, key):
    if key in dict.keys():
        return True
    else:
        return False
        
def checkVal(dict, Val):
    if Val in dict.values():
        return True
    else:
        return False


def open_folder(path):
    if sys.platform == 'darwin':
        subprocess.check_call(['open', '--', path])
    elif sys.platform == 'linux2':
        subprocess.check_call(['gnome-open', '--', path])
    elif sys.platform == 'win32':
        subprocess.check_call(['explorer', path])
        
def forbidden_Chr():
    if platform == 'win32':
        Chr = ["<",">",":",'"',"/","*",'?',"|","\\"]
        return Chr
    elif platform == 'darwin':
        Chr = [':','.']
        return Chr