#**********************************************
# March,4th, 2022. Ok. Created by Jiajing Qi
# Design Layer Tool V1.2
#   
#   This script assigns pen color, line weight, class to objects on specified layer.
#   Follow up www.7-lights.com for updates
#***********************************************

import vs

def DL_tool ():
    # control IDs
    kOK                     = 1
    kCancel                 = 2
    kInstruction_Group_Text = 4
    kT1                     = 5
    kT2                     = 6
    kT3                     = 7
    kSetting_Group_Text     = 10
    kT5                     = 11
    kLayer_Text             = 12
    kLayer_Popup            = 13
    kAssign_Class_CheckBox  = 14
    kAttr_Text              = 15
    kLw_Text                = 16
    kLW_Popup               = 17
    kColor_Text             = 18
    kColor_Popup            = 19
    kClass_Text             = 20
    kClass_Popup            = 21
    kDate_Text              = 22
    kCreated_by_Text        = 23
    kCheck_Symbol           = 24

    def CreateDialog():
        # Alignment constants
        kRight                  = 1
        kBottom                 = 2
        kLeft                   = 3
        kColumn                 = 4
        kResize                 = 0
        kShift                  = 1

        def GetPluginString(ndx):
            # Static Text
            if ndx == 1001:         return 'Apply'
            elif ndx == 1002:       return 'Cancel'
            elif ndx == 1003:       return 'Design Layer Tool V1.2'
            elif ndx == 1004:       return 'Instruction'
            elif ndx == 1005:       return 'This tool assigns objects on a specified design layer'
            elif ndx == 1006:       return 'with user defined line weight,pen color'
            elif ndx == 1007:       return 'and class'
            elif ndx == 1010:       return 'Settings'
            elif ndx == 1011:       return 'All objects in this layer will be appied with new attributes'
            elif ndx == 1012:       return 'Select a design layer'
            elif ndx == 1013:       return ''
            elif ndx == 1014:       return 'Assign Class'
            elif ndx == 1015:       return 'Attributes'
            elif ndx == 1016:       return 'Choose Line Weight'
            elif ndx == 1017:       return ''
            elif ndx == 1018:       return 'Choose color'
            elif ndx == 1019:       return ''
            elif ndx == 1020:       return 'Choose class that objects will be assigned to'
            elif ndx == 1021:       return ''
            elif ndx == 1022:       return 'June,12, 2020'
            elif ndx == 1023:       return 'V1.2. Created by Jiajing Qi'
            elif ndx == 1024:       return 'Apply class changes to nested symbol class'
            # Help Text
            elif ndx == 2001:       return 'Apply attributes to objects'
            elif ndx == 2002:       return 'Never Mind'
            elif ndx == 2004:       return ''
            elif ndx == 2005:       return ''
            elif ndx == 2006:       return ''
            elif ndx == 2007:       return ''
            elif ndx == 2010:       return ''
            elif ndx == 2011:       return ''
            elif ndx == 2012:       return ''
            elif ndx == 2013:       return 'All objects on this layer will be applied to new attributes'
            elif ndx == 2014:       return 'Check this to assign class to all objects'
            elif ndx == 2015:       return ''
            elif ndx == 2016:       return ''
            elif ndx == 2017:       return 'New line weight will apply to objects '
            elif ndx == 2018:       return ''
            elif ndx == 2019:       return 'Selected Color will apply to all objects'
            elif ndx == 2020:       return ''
            elif ndx == 2021:       return 'Class name that objects will be assinged to'
            elif ndx == 2022:       return 'Follow me: 7-lights.com'
            elif ndx == 2023:       return 'Follow me: 7-lights.com'
            elif ndx == 2024:       return 'Apply class changes within Symbol'
            return ''

        def GetStr(ndx):
            result = GetPluginString( ndx + 1000 )
            return result

        def GetHelpStr(ndx):
            result = GetPluginString( ndx + 2000 )
            return result

        dialog = vs.CreateLayout( GetStr(3), True, GetStr(kOK), GetStr(kCancel) )

        # create controls
        vs.CreateGroupBox( dialog, kInstruction_Group_Text, GetStr(kInstruction_Group_Text), True )
        vs.CreateStaticText( dialog, kT1, GetStr(kT1), -1 )
        vs.CreateStaticText( dialog, kT2, GetStr(kT2), -1 )
        vs.CreateStaticText( dialog, kT3, GetStr(kT3), -1 )
        vs.CreateGroupBox( dialog, kSetting_Group_Text, GetStr(kSetting_Group_Text), True )
        vs.CreateStaticText( dialog, kT5, GetStr(kT5), -1 )
        vs.CreateStaticText( dialog, kLayer_Text, GetStr(kLayer_Text), -1 )
        vs.CreateDesignLayerPullDownMenu( dialog, kLayer_Popup, 25 )
        vs.CreateGroupBox( dialog, kAttr_Text, GetStr(kAttr_Text), True )
        vs.CreateStaticText( dialog, kLw_Text, GetStr(kLw_Text), -1 )
        vs.CreateLineWeightPopup( dialog, kLW_Popup )
        vs.CreateStaticText( dialog, kColor_Text, GetStr(kColor_Text), -1 )
        vs.CreateColorPopup( dialog, kColor_Popup, 25 )
        vs.CreateCheckBoxGroupBox( dialog, kAssign_Class_CheckBox, GetStr(kAssign_Class_CheckBox), True )
        vs.CreateStaticText( dialog, kClass_Text, GetStr(kClass_Text), -1 )
        vs.CreateClassPullDownMenu( dialog, kClass_Popup, 25 )
        vs.CreateCheckBox( dialog, kCheck_Symbol, GetStr(kCheck_Symbol) )
        vs.CreateStaticText( dialog, kCreated_by_Text, GetStr(kCreated_by_Text), -1 )
        vs.CreateStaticText( dialog, kDate_Text, GetStr(kDate_Text), -1 )

        # set relations
        vs.SetFirstLayoutItem( dialog, kInstruction_Group_Text )
        vs.SetFirstGroupItem( dialog, kInstruction_Group_Text, kT1 )
        vs.SetRightItem( dialog, kInstruction_Group_Text, kSetting_Group_Text, 0, 0 )
        vs.SetBelowItem( dialog, kInstruction_Group_Text, kCreated_by_Text, 0, 0 )
        vs.SetBelowItem( dialog, kT1, kT2, 0, 0 )
        vs.SetBelowItem( dialog, kT2, kT3, 0, 0 )
        vs.SetFirstGroupItem( dialog, kSetting_Group_Text, kT5 )
        vs.SetBelowItem( dialog, kT5, kLayer_Text, 0, 0 )
        vs.SetBelowItem( dialog, kLayer_Text, kLayer_Popup, 0, 0 )
        vs.SetBelowItem( dialog, kLayer_Popup, kAttr_Text, 0, 0 )
        vs.SetFirstGroupItem( dialog, kAttr_Text, kLw_Text )
        vs.SetBelowItem( dialog, kAttr_Text, kAssign_Class_CheckBox, 0, 0 )
        vs.SetBelowItem( dialog, kLw_Text, kLW_Popup, 0, 0 )
        vs.SetBelowItem( dialog, kLW_Popup, kColor_Text, 0, 0 )
        vs.SetBelowItem( dialog, kColor_Text, kColor_Popup, 0, 0 )
        vs.SetFirstGroupItem( dialog, kAssign_Class_CheckBox, kClass_Text )
        vs.SetBelowItem( dialog, kClass_Text, kClass_Popup, 0, 0 )
        vs.SetBelowItem( dialog, kClass_Popup, kCheck_Symbol, 0, 0 )
        vs.SetBelowItem( dialog, kCreated_by_Text, kDate_Text, 0, 0 )

        # set alignments
        vs.AlignItemEdge( dialog, kInstruction_Group_Text, kRight, 1, kResize );

        # set help strings
        cnt = 1
        while ( cnt <= 24 ):
            vs.SetHelpText( dialog, cnt, GetHelpStr(cnt) )
            cnt += 1

        return dialog

    def DialogHandler(item, data):
        Checkbox_Status = vs.GetBooleanItem(dlg,24)
        Assig_Class_Status = vs.GetBooleanItem(dlg,14)
        Source_Layer = vs.GetItemText(dlg,13)
        Chinese_Layer_name = repr(Source_Layer )
        Layer_Handle = vs.GetLayerByName(Source_Layer)
        LW = vs.GetLineWeightChoice(dlg,17)
        LW_in_mm = str(round((LW * 0.025),2))
        Color = vs.GetColorChoice(dlg,19)
        Color_RGB = str(vs.ColorIndexToRGB(Color))
        Target_Class = str(vs.GetItemText(dlg,21))
        Chinese_Class_name = repr(Target_Class)
        #vs.AlrtDialog(Layer_Handle)
        if item == kOK and Source_Layer == "New Design Layer...": #Check if any design layer been selected
            vs.AlrtDialog("Select design layer first !")
        elif item == kOK :  # Design layer has been selected and user press APPLY button on dialog
            list = vs.FInLayer(Layer_Handle)
            my_layer = vs.GetLayerByName(Source_Layer)
        # Check if selected layer has any objects on it
            CheckOBJ = vs.NumObj(((my_layer)))
        # Get numbers of total objects on selected layer
            OBJ_Num = repr(CheckOBJ ) 
        # If no onjects on selected layer, get alert. Otherwise, proceed.
            if CheckOBJ == 0:
                vs.AlrtDialog("Assign object to  " + Chinese_Layer_name +" design layer first !" + "\n" +"No objects on " + Chinese_Layer_name+ " design layer yet" )
            else:
        # Assign color and lineweight to  objects
                def ChangeLw(h):  
                    vs.SetLW(h, LW)
                    vs.SetPenFore(h,Color)
                    return()
        # Assign objects to select Class
                def AssignClass(h): 
                    vs.SetClass(h,Target_Class)
                    return ()
        #Substitute layer's name in selection criteria      
                Selection_Criteria = "INSYMBOL & INVIEWPORT & (L=LayerName)"
                User_Defined_Criteria = Selection_Criteria.replace("LayerName",Chinese_Layer_name)
        # Not apply class changes within symbol
                if Assig_Class_Status == 0 :
                    vs.ForEachObject(ChangeLw,((User_Defined_Criteria))) 
                    vs.AlrtDialog("( " + OBJ_Num + " )" + "Objects in  " + Chinese_Layer_name + " Layer have been assigned to:" + "\n"+ "\n"
                    "1. LineWeight : "+ LW_in_mm + "\n"
                    "2. RGB Color in 16 bit : " + Color_RGB + "\n")
        # Apply class changes with in symbol
                elif (Assig_Class_Status == 1) and (Checkbox_Status == 1):
                    vs.ForEachObject(ChangeLw,((User_Defined_Criteria))) 
                    vs.ForEachObjectInList(AssignClass, 0, 1,list)
                    vs.ForEachObjectInList(AssignClass, 0, 2, vs.FSymDef())
                    vs.AlrtDialog("( " + OBJ_Num + " )" + "Objects in  " + Chinese_Layer_name + " Layer have been assigned to:" + "\n"+ "\n"
                    "1. LineWeight : "+ LW_in_mm + "\n"
                    "2. RGB Color in 16 bit : " + Color_RGB + "\n"
                    "3. Assigned objects to class (Includes nested symbol class)  : "+ Target_Class )
                elif (Assig_Class_Status == 1) and (Checkbox_Status == 0):
                    vs.ForEachObject(ChangeLw,((User_Defined_Criteria))) 
                    vs.ForEachObjectInList(AssignClass, 0, 1,list)
                    vs.AlrtDialog("( " + OBJ_Num + " )" + "Objects in  " + Chinese_Layer_name + " Layer have been assigned to:" + "\n"+ "\n"
                    "1. LineWeight : "+ LW_in_mm + "\n"
                    "2. RGB Color in 16 bit : " + Color_RGB + "\n"
                    "3. Assigned objects to class (Not includes nested symbol class) : "+ Target_Class)
                

    dlg = CreateDialog()
    vs.RunLayoutDialog( dlg, DialogHandler )
